package br.com.alura.sreenmatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SreenmatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
