package br.com.alura.sreenmatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SreenmatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(SreenmatchApplication.class, args);
	}

}
